package com.yanan.framework.webmvc.session.interfaceSupport;

public interface TokenType {

	public static final int TOKEN_RPC_TCP = 4280;

}