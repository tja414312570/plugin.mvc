package com.yanan.framework.webmvc.session.interfaceSupport;

public interface TokenSupport {
	public void doFilter();
}