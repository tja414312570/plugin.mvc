package com.yanan.framework.webmvc.session.exception;

public class TokenIdIsNullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}