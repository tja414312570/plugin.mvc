package com.yanan.framework.webmvc.session.interfaceSupport;

public interface Token_Command_Type {
	public static final String COMMAND_REDIRECT="redirect";
	public static final String COMMAND_FORWARD="forward";
	public static final String COMMAND_OUTPUT="output";
	public static final String COMMAND_CHAIN="chain";
}