package com.yanan.framework.webmvc.session.plugin;

public class PermissionAuthException extends RuntimeException {

	public PermissionAuthException(String msg) {
		super(msg);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 3389324287830364401L;

}